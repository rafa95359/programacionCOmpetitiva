# @author Matheus Alves dos Santos
# TITLE: Game with Sticks
# ID: 451A

n, m = map(int, raw_input().split())

if (min(n, m) % 2 == 0):
    print "Malvika"
else:
    print "Akshat"
