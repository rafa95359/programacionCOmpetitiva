# @author Matheus Alves dos Santos
# TITLE: Lineland Mail
# ID: 567A

n = int(raw_input())
cities = map(int, raw_input().split())

print abs(cities[1] - cities[0]), abs(cities[n - 1] - cities[0])

for i in range(1, n - 1):
    nearest = min(abs(cities[i] - cities[i - 1]), abs(cities[i + 1] - cities[i]))
    farthest = max(abs(cities[i] - cities[0]), abs(cities[n - 1] - cities[i]))
    print nearest, farthest

print abs(cities[n - 1] - cities[n - 2]), abs(cities[n - 1] - cities[0])
