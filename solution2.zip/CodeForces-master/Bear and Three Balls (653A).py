# @author Matheus Alves dos Santos
# TITLE: Bear and Three Balls
# ID: 653A

n_balls = int(raw_input())
happy = False

balls = map(int, raw_input().split())
balls.sort()

for i in range(len(balls) - 1, 0, -1):
    if balls[i] == balls[i - 1]:
        balls.pop(i)

for i in range(0, len(balls) - 2):
    if ((balls[i] + 1) == balls [i + 1]) and ((balls[i] + 2) == balls [i + 2]):
        happy = True
        break

if (happy):
    print "YES"
else:
    print "NO"
    


