// @author Matheus Alves dos Santos
// TITLE: Elephant
// ID: 617A

#include <iostream>

using namespace std;

int main() {
    int distance, steps = 0;
    
    cin >> distance;
    
    steps += (distance / 5);
    if ((distance % 5) != 0) {
        steps ++;
    }
    
    cout << steps;

    return 0;
}
