# @author Matheus Alves dos Santos
# TITLE: Joysticks
# ID: 651A

player1, player2 = map(int, raw_input().split())

minutos = 0

while player1 > 0 and player2 > 0:
    
    if player1 == 1 and player2 == 1:
        break
    
    elif player1 == 1 and player2 > 1:
        player1 += 1
        player2 -= 2
    
    elif player1 > 1 and player2 == 1:
        player2 += 1
        player1 -= 2
    
    else:
        if player1 > player2:
            player1 -= 2
            player2 += 1
        else:
            player1 += 1
            player2 -= 2
    minutos += 1

print minutos
