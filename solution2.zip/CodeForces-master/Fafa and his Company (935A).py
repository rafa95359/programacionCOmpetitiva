# @author Matheus Alves dos Santos
# TITLE: Fafa and his Company
# ID: 935A

n_employees = int(raw_input())

leaders, pawns = n_employees - 1, 1
answer = 1

for i in range(n_employees / 2):
    leaders -= 1
    pawns += 1
    
    if leaders % pawns == 0:
        answer += 1

if n_employees == 2:
    answer = 1
    
print answer
    
    
        
    
    
