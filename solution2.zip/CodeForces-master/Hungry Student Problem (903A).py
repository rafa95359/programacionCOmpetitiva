# @author Matheus Alves dos Santos
# TITLE: Hungry Student Problem
# ID: 903A

not_possible = [1, 2, 4, 5, 8, 11]

n_tests = int(raw_input())

for i in range(n_tests):
    number = int(raw_input())
    
    if number in not_possible:
        print 'NO'
    else:
        print 'YES'
