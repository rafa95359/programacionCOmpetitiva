# @author Matheus Alves dos Santos
# TITLE: Protect Sheep
# ID: 948A

possible = True
pasture = []

r, c = map(int, raw_input().split())

for i in range(r):
    pasture.append(raw_input().replace('.', 'D'))
    
for i in range(r):
    for j in range(c):
        if pasture[i][j] == 'S':            
            
            if (i > 0):
                if pasture[i - 1][j] == 'W':
                    possible = False
            if (i < r - 1):
                if pasture[i + 1][j] == 'W':
                    possible = False
            
            if (j > 0):
                if pasture[i][j - 1] == 'W':
                    possible = False
            if (j < c - 1):
                if pasture[i][j + 1] == 'W':
                    possible = False

if (possible):
    print 'Yes'
    for i in pasture:
        print i
else:
    print 'No'
             
