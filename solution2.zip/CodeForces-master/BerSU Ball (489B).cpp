// @author Matheus Alves dos Santos
// TITLE: BerSU Ball
// ID: 489B

#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int main() {
    int n_boys, n_girls, answer = 0;
    bool matched[110];
    
    cin >> n_boys;
    int boys_ability[n_boys];
    for(int i = 0 ; i < n_boys ; i++) {
        cin >> boys_ability[i];
    }
    
    cin >> n_girls;
    int girls_ability[n_girls];
    for(int i = 0 ; i < n_girls ; i++) {
        cin >> girls_ability[i];
    }
    
    for(int i = 0 ; i < 110 ; i++) {
        matched[i] = false;
    }
    
    sort(boys_ability, boys_ability + n_boys);
    sort(girls_ability, girls_ability + n_girls);
 
    for(int i = 0 ; i < n_boys ; i++) {
        for(int j = 0 ; j < n_girls ; j++) {
            if( (abs(boys_ability[i] - girls_ability[j]) < 2) && !matched[j]) {
                matched[j] = true;
                answer++;
                break;
            }
        }
    }
    
    cout << answer << endl;
    
    return 0;
}
