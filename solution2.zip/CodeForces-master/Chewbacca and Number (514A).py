# @author Matheus Alves dos Santos
# TITLE: Chewbacca and Number
# ID: 514A

digits = raw_input()
inverted = ''

for i in digits:
    if(int(i) >= 5):
        inverted += str(9 - int(i))
    else:
        inverted += i

digits = ''
if inverted[0] == '0':
    digits += '9'
else:
    digits += inverted[0]
    
for i in range (1, len(inverted)):
    digits += inverted[i]
    
print digits
