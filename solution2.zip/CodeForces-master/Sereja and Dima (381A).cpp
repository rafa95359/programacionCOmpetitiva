// @author Matheus Alves dos Santos
// TITLE: Sereja and Dima
// ID: 381A

#include <iostream>

using namespace std;

int main(){
    int n_cards, pointer1, pointer2, p1_points = 0, p2_points = 0; 
    bool player = true;
    cin >> n_cards;
    
    int cards[n_cards];
    for (int i = 0; i < n_cards; i++) {
        cin >> cards[i];
    }
    
    pointer1 = 0;
    pointer2 = n_cards - 1;
    
    for (int i = 0; i < n_cards; i++) {
        if ((n_cards % 2 == 0) && (pointer2 < pointer1)) {
            break;
        }
        
        if (player) {
            if (cards[pointer1] >= cards[pointer2]) {
                p1_points += cards[pointer1];
                pointer1++;
            } else {
                p1_points += cards[pointer2];
                pointer2--;
            }
            player = false;
        } else {
            if (cards[pointer1] >= cards[pointer2]) {
                p2_points += cards[pointer1];

                pointer1++;
            } else {
                p2_points += cards[pointer2];
                pointer2--;
            }
            player = true;
        }
    }
    
    cout << p1_points << " " << p2_points;
    return 0;
}
