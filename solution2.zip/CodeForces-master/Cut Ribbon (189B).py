# @author Matheus Alves dos Santos
# TITLE: Cut Ribbon
# ID: 189B

n, a, b, c = map(int, raw_input().split())

sizes = [a, b, c]
sizes.sort(reverse = True)

dp = [0] * (n + 1)
counter = [0] * (n + 1)

for i in range(len(dp)):
    for j in range(3):
        if sizes[j] <= i:
            
            if dp[i - sizes[j]] + sizes[j] >= dp[i]:
                dp[i] = dp[i - sizes[j]] + sizes[j]
                counter[i] = max(counter[i], counter[i - sizes[j]] + 1)
    
print counter[n]
