// @author Matheus Alves dos Santos
// TITLE: Pasha and Stick
// ID: 610A

#include <iostream>
#include <cmath>

using namespace std;

int main() {
    int length, rects;
    cin >> length;
    
    if ((length % 2) != 0) {
        rects = 0;
    } else {
        rects = length / 4;
    }
    
    if ((length % 4) == 0) {
        rects --;
    }
    
    cout << rects;
        
    return 0;
}
