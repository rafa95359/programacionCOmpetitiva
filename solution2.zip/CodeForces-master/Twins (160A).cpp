// @author Matheus Alves dos Santos
// TITLE: Twins
// ID: 160A

#include <iostream>
#include <algorithm>

using namespace std;

int main(){

    int n_coins, sum_coins = 0, sum_taken = 0, coins_taken = 0;
    
    cin >> n_coins;
    int coins[n_coins];
    
    for(int i = 0; i < n_coins; i++) {
        cin >> coins[i];
        sum_coins += coins[i];
    }
    
    sort(coins, coins + n_coins);
    
    for(int i = n_coins - 1; i >= 0; i--) {
        sum_coins -= coins[i];
        sum_taken += coins[i];
        coins_taken++;
        
        if (sum_coins < sum_taken) {
        break;
        }
    }
    
    cout << coins_taken;
    
    return 0;
}
