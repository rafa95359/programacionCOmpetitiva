// @author Matheus Alves dos Santos
// TITLE: Queue at the School
// ID: 266B

#include <iostream>
#include <string>

using namespace std;

int main() {
    int size, time;
    string queue;
    
    cin >> size >> time;
    cin >> queue;
    
    for (int i = 0; i < time; i++) {
        for (int j = 1; j < size; j++) {
            if ((queue[j] == 'G') && (queue[j - 1] == 'B')) {
                queue[j] = 'B';
                queue[j - 1] = 'G';
                j++;
            }
        }
    }
    
    cout << queue << endl;
    
    return 0;
    
}
