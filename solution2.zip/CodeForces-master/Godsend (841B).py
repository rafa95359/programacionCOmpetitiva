# @author Matheus Alves dos Santos
# TITLE: Godsend
# ID: 841B

odds = 0
lenght = int(raw_input())
numbers = map(int, raw_input().split())

for i in numbers:
    if (i % 2):
        odds += 1;

if (odds > 0):
    print "First"
else:
    print "Second"
