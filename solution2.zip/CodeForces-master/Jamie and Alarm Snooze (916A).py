# @author Matheus Alves dos Santos
# TITLE: Jamie and Alarm Snooze
# ID: 916A

snooze = int(raw_input())
hours, minutes = map(int, raw_input().split())
times = 0

while True:
    if '7' in (str(hours) + str(minutes)):
        break
    
    times += 1    
    minutes -= snooze
    
    if minutes < 0:
        minutes += 60
        hours -= 1
    
    if hours < 0:
        hours += 24

print times
