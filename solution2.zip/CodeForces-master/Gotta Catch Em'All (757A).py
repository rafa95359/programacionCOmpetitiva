# @author Matheus Alves dos Santos
# TITLE: Gotta Catch Em'All
# ID: 757A

a = raw_input()
b = [0, 0, 0, 0, 0, 0, 0]

for i in a:
    if i == 'B':
        b[0] += 1
    elif i == 'u':
        b[1] += 1
    elif i == 'l':
        b[2] += 1
    elif i == 'b':
        b[3] += 1
    elif i == 'a':
        b[4] += 1
    elif i == 's':
        b[5] += 1
    elif i == 'r':
        b[6] += 1

b[1], b[4] = b[1]/2, b[4]/2

print min(b)
