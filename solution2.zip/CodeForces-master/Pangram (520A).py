# @author Matheus Alves dos Santos
# TITLE: Pangram
# ID: 520A

n_letters = int(raw_input())
phrase = set(raw_input().lower())

if (len(phrase) == 26):
    print "YES"
else:
    print "NO"
