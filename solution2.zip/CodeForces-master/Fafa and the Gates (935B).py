# @author Matheus Alves dos Santos
# TITLE: Fafa and the Gates
# ID: 935B

x, y = 0, 0
coins = 0

n_moves = int(raw_input())
moves = raw_input()

if moves[0] == "U":
    x_bigger = False
    y += 1
else:
    x_bigger = True
    x += 1

for i in range(1, len(moves)):
    if moves[i] == "R":
        x += 1
    else:
        y += 1
        
    if x_bigger:
        if x < y:
            coins += 1
            x_bigger = False
    else:
        if x > y:
            coins += 1
            x_bigger = True

print coins
    
