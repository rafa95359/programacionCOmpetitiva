// @author Matheus Alves dos Santos
// TITLE: Wet Shark and Bishops
// ID: 621B

#include <iostream>

using namespace std;

int main() {
    int n_bishops, x, y, battles = 0, plus[2000] = {}, minus[2000] = {};
    cin >> n_bishops;
    
    for(int i = 0; i < n_bishops; i++) {
        cin >> x >> y;
        plus[x + y]++;
        minus[x - y + 1000]++;
    }
    
    for(int i = 0; i < 2000; i++) {
            battles += (plus[i] * (plus[i] - 1) / 2);
            battles += (minus[i] * (minus[i] - 1) / 2);
    }
    
    cout << battles << endl;
    
    return 0;
}
