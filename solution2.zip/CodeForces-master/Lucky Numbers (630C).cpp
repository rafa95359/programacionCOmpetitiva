// @author Matheus Alves dos Santos
// TITLE: Lucky Numbers
// ID: 630C

#include <iostream>
#include <cmath>

using namespace std;

int main() {
    long long int digits, answer = 0;
    cin >> digits;
    
    for(int i = 1; i <= digits; i++) {
        if ((i % 2) == 0) {
            answer += (pow(2, i/2) * pow(2, i/2));
        } else {
            answer += (pow(2, i/2) * pow(2, 1 + (i/2)));
        }
    }
    
    cout << answer;
    
    return 0;
}
