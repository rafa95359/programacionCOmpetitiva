// @author Matheus Alves dos Santos
// TITLE: Ice Skating
// ID: 217A

#include<iostream>
  
using namespace std;  

struct drift {
    int x, y;
};

int n_drifts; 
bool visited[1010] = {false};
drift drifts[1010];  
  
void dfs(int node){
    visited[node] = true;
      
    for (int i = 1; i <= n_drifts; i++) {  
        if (!visited[i] && (drifts[node].x == drifts[i].x || drifts[node].y == drifts[i].y)) {   
            dfs(i);  
        }  
    }
      
}  
  
int main() {
    
    cin >> n_drifts;
    
    for (int i = 1; i <= n_drifts; i++) { 
        drift d;
        cin >> d.x >> d.y;
        drifts[i] = d;
    }
    
    int answer = 0;
      
    for (int i = 1; i <= n_drifts; i++) {  
        if (!visited[i]) {  
            dfs(i);  
            answer++;  
        }  
    }  
    
    cout << answer - 1 << endl;
      
    return 0;  
    
}  
