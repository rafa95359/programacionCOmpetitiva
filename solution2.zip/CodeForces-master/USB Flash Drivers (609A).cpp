// @author Matheus Alves dos Santos
// TITLE: USB Flash Drivers
// ID: 609A

#include <iostream>
#include <algorithm>

using namespace std;

int main(){

    int n_usbs, filesize, filled = 0;
    
    cin >> n_usbs;
    cin >> filesize;
    int capacity[n_usbs];
    
    for(int i = 0; i < n_usbs; i++) {
        cin >> capacity[i];
    }
    
    sort(capacity, capacity + n_usbs);
    
    for(int i = n_usbs - 1; i >= 0; i--) {
        filesize -= capacity[i];
        filled++;
        
        if (filesize <= 0) {
            break;
        }
    }
    
    cout << filled;
    
    return 0;
}
