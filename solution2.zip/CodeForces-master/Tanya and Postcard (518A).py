# @author Matheus Alves dos Santos
# TITLE: Tanya and Postcard
# ID: 518A

def invert_case(c):
	if c.isupper():
		return c.lower()
	return c.upper()

yay = 0
whoops = 0
letters = { }

for c in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ":
	letters[c] = 0

message = list(raw_input())
newspaper = list(raw_input())

for c in newspaper:
	letters[c] += 1

for i in range(len(message)):
	if (letters[message[i]] > 0):
		letters[message[i]] -= 1
		yay += 1
		message[i] = "."

for i in range(len(message) - 1, -1 , -1):
	if message[i] == ".":
		message.pop(i)

for c in message:
	if (letters[invert_case(c)] > 0):
		letters[invert_case(c)] -= 1
		whoops += 1

print yay, whoops
