// @author Matheus Alves dos Santos
// TITLE: DZY Loves Chessboard
// ID: 445A

#include <iostream>

using namespace std;

int main() {
    int height, width;
    string line;
    
    cin >> height >> width;
    
    for (int i = 0; i < height; i++) {
        cin >> line;
        
        for (int j = 0; j < width; j++) {
            if (line[j] == '.') {
                if ((i % 2) == (j % 2)) {
                    line[j] = 'B';
                } else {
                    line[j] = 'W';
                }
            }
        }
        cout << line << endl;
    }
    
    return 0;
    
}
