// @author Matheus Alves dos Santos
// TITLE: The World is a Theatre
// ID: 131C

#include <iostream>

using namespace std;

long long Combination(int n, int m) {
    long long result = 1;
    for (int i = 0; i < m; i++) {
        result *= (n - i);
        result /= (i + 1);
    }
    
    return result;
}

int main()
{
    int boys, girls, actors;
    cin >> boys >> girls >> actors;

    long long ways = 0;
    for (int i = 4; i <= actors - 1; ++i) {
        ways += Combination(boys, i) * Combination(girls, actors - i);
    }
    
    cout << ways << endl;
    
    return 0;
}
