# @author Matheus Alves dos Santos
# TITLE: Find Extra One
# ID: 900A

n_points = int(raw_input())

left = 0
right = 0

for i in range(n_points):
    if (int(raw_input().split()[0]) < 0):
        left += 1
    else:
        right += 1
        
if ((left > 1) and (right > 1)):
    print "No"
else:
    print "Yes"
