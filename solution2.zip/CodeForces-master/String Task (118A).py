# @author Matheus Alves dos Santos
# TITLE: String Task
# ID: 118A

a = raw_input().lower()
b = 'aoyeui'
c = ''

for i in a:
    if i not in b:
        c += ('.' + i)

print c
