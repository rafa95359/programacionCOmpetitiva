## CodeForces

##### The main purpose of this repository is to store solutions to some of the CodeForces problems.

These solutions were mostly written in C++ or Python 2.7 and were developed by the owner of this profile. 

