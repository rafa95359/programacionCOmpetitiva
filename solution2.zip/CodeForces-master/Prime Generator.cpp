// @author Matheus Alves dos Santos
// TITLE: Prime Generator
// ID: PRIME1

#include <iostream>
#include <cmath>

using namespace std;

int main() {
    int number1, number2, nTests;
    
    cin >> nTests;
    
    for(int i = 0; i < nTests; i++) {
        cin >> number1 >> number2;
        if (number1 == 1) {
            number1++;
        }
        if (number2 == 1) {
            number2++;
        }
        
        for(int j = number1; j <= number2; j++) {
            bool isPrime = true;
            
            for(int k = 2; k <= sqrt(j); k++) {
                if(j % k == 0) {
                    isPrime = false;
                    break;
                }
            }
            
            if (isPrime) {
                cout << j << endl;
            }
        }
        cout << endl;
            
    }
        
        
    return 0;
}
