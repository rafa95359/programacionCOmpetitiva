// @author Matheus Alves dos Santos
// TITLE: Gravity Flip
// ID: 405A

#include <iostream>
#include <algorithm>

using namespace std;

int main(){

    int n_columns;
    
    cin >> n_columns;
    int box[n_columns];
    
    for(int i = 0; i < n_columns; i++) {
        cin >> box[i];
    }
    
    sort(box, box + n_columns);
    
    for(int i = 0; i < n_columns; i++) {
        cout << box[i] << " ";
    }
    
    return 0;
}
