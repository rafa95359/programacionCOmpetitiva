// @author Matheus Alves dos Santos
// TITLE: Queries about less or equal elements
// ID: 600B

#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
  int a_size, b_size, b;
  cin >> a_size >> b_size;
  vector<int> a(a_size);

  for(int i = 0; i < a_size; i++){
      cin >> a[i];
  }
  sort(a.begin(), a.end());

  for(int i = 0; i < b_size; i++) {
    cin >> b;
    vector<int>::iterator upper = std::upper_bound(a.begin(), a.end(), b);
    int u = upper - a.begin();
    cout << u << " ";
  }
  
  return 0;
}
