// @author Matheus Alves dos Santos
// TITLE: Cheap Travel
// ID: 466A

#include <iostream>
#include <cmath>

using namespace std;

int main() {
    int travels, packs, single, special;
    cin >> travels >> packs >> single >> special;
    
    bool s_rides = true;
    if (packs * single <= special) {
        s_rides = false;
    }
    
    if (s_rides) {
        int cost_packs = 0, cost_hibrid = 0;
        
        cost_hibrid += (travels / packs) * special;
        cost_hibrid += (travels % packs) * single;
        
        if ((travels % packs) == 0) {
            cost_packs += (travels / packs) * special;
        } else {
            cost_packs += ((travels / packs) * special) + special;
        }
        
        cout << min(cost_hibrid, cost_packs);
    } else {
        cout << travels * single;
    }
        
    return 0;
}
