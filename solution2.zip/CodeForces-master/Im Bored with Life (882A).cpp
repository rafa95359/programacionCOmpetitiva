// @author Matheus Alves dos Santos
// TITLE: I'm bored with life
// ID: 882A

#include <iostream>

using namespace std;

int main() {

    int number1, number2, minimum, factorial = 1;
    
    cin >> number1 >> number2;
    minimum = min(number1, number2);
    while (minimum > 1) {
        factorial *= minimum;
        minimum--;
    }
    
    cout << factorial;
    
    return 0;
}
