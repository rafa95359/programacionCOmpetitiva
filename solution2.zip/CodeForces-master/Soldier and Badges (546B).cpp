// @author Matheus Alves dos Santos
// TITLE: Soldier and Badges
// ID: 546B

#include <iostream>
#include <algorithm>

using namespace std;

int main(){

    int n_badges, coins, aux = 1;
    bool reorder = false;
    
    cin >> n_badges;
    int badges[n_badges];
    
    for(int i = 0; i < n_badges; i++) {
        cin >> badges[i];
    }
    
    sort(badges, badges + n_badges);
    
    coins = 0;
    for(int i = 0; i < n_badges - 1; i++) {
        do {
            if (badges[i] == badges[i + aux]) {
                badges[i + aux] += aux;
                coins += aux;
                aux++;
                reorder = true;
            }
        } while (badges[i] == badges[i + aux]);
        
        aux = 1;
        if (reorder) {
            sort(badges, badges + n_badges);
            reorder = false;
            i = 0;
        }
    }
    cout << coins;
    
    return 0;
}
