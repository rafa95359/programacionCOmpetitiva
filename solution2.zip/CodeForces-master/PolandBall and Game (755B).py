# @author Matheus Alves dos Santos
# TITLE: PolandBall and Game
# ID: 755B

n, m = map(int, raw_input().split())

p_words = {}
both_know = 0

for i in range(n):
    p_words[raw_input()] = True

for i in range(m):
    if (p_words.has_key(raw_input())):
        both_know += 1

if (m > n) or ((n == m) and (both_know % 2 == 0)):
    print "NO"
else:
    print "YES"
