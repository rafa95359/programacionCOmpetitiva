# @author Matheus Alves dos Santos
# TITLE: Beautiful Divisors
# ID: 893B

beautiful = [1, 6, 28, 120, 496, 2016, 8128, 32640, 130816]

entrada = int(raw_input())

for i in beautiful:
    if ((entrada % i) == 0):
        greater = i

print greater
