# @author Matheus Alves dos Santos
# TITLE: T-primes
# ID: 230B

import math

is_prime = [True] * 1000001
size = int(math.ceil(math.sqrt(len(is_prime))))

is_prime[0] = False
is_prime[1] = False

for i in range(2, size):
    if (is_prime[i]):
        for j in range(i + i, len(is_prime), i):
            is_prime[j] = False

quantity = int(raw_input())
numbers = map(int, raw_input().split())


for i in numbers:
    sqrt = math.sqrt(i)
    
    if (sqrt % 1 == 0):
        answer = is_prime[int(sqrt)]
    else:
        answer = False
        
    if answer:
        print "YES"
    else:
        print "NO"
