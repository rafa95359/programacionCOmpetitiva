// @author Matheus Alves dos Santos
// TITLE: Complicated GCD
// ID: 664A

#include <iostream>

using namespace std;

int main() {

    string numbers[2];
    
    cin >> numbers[0] >> numbers[1];
    if (numbers[0] == numbers[1]) {
        cout << numbers[0];
    } else {
        cout << "1";
    }
    
    return 0;
}
