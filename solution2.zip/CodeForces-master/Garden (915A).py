# @author Matheus Alves dos Santos
# TITLE: Garden
# ID: 915A

info = map(int, raw_input().split())
bucket = map(int, raw_input().split())
bucket = sorted(bucket, reverse = True)


for i in bucket:
    if (info[1] % i == 0):
        print info[1] / i
        break
