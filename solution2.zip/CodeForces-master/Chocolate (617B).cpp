// @author Matheus Alves dos Santos
// TITLE: Chocolate
// ID: 617B

#include <iostream>
 
using namespace std;
 
int main() {
    int pieces, previous = -1;
    long long answer = 0;
    
    cin >> pieces;
    for (int i = 0; i < pieces; i++) {
        
        int isNut;
        cin >> isNut;
        
        if (isNut == 1) {
            if (previous == -1) {
                answer = 1;
            } else {
                answer *= i - previous;
            }
            
            previous = i;
        }
    }
 
    cout << answer << endl;
}
