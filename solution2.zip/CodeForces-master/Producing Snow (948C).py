# @author Matheus Alves dos Santos
# TITLE: Producing Snow
# ID: 948C

days = int(raw_input())
piles = map(int, raw_input().split())
temps = map(int, raw_input().split())

melted = [0] * days

for i in range(days):
    for j in range(i + 1):
        
        melted[i] += ( min(temps[i], piles[j]) )
        piles[j] -= min(temps[i], piles[j])
        
        if i == j:
            break

print " ".join(map(str, melted))
