# @author Matheus Alves dos Santos
# TITLE: Perfect Squares
# ID: 914A

n = int(raw_input())
sequence = sorted(map(int, raw_input().split()), reverse = True)

for i in sequence:
    if i < 0:
        not_square = i
        break
    elif round(i ** 0.5) ** 2 != i:
        not_square = i
        break

print not_square

