# @author Matheus Alves dos Santos
# TITLE: Olesya and Rodion
# ID: 584A

rules = map(int, raw_input().split())
number = ''

if ((rules[1] == 10) and (rules[0] == 1)):
    number = -1
    
elif (rules[1] == 10):
    number += str(rules[1])
    for i in range(rules[0] - 2):
        number += '0'

else:
    for i in range(rules[0]):
        number += str(rules[1])

print number
        
