// @author Matheus Alves dos Santos
// TITLE: Currency System in Geraldion
// ID: 560A

#include <iostream>
#include <algorithm>

using namespace std;

int main() {
    int nNotes;
    cin >> nNotes;
    
    int notes[nNotes];
    for(int i = 0; i < nNotes; i++) {
        cin >> notes[i];
    }
    
    sort(notes, notes + nNotes);
    if (notes[0] == 1) {
        cout << "-1";
    } else {
        cout << "1";
    }

        return 0;
    }
