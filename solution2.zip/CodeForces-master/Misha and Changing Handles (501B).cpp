// @author Matheus Alves dos Santos
// TITLE: Misha and Changing Handles
// ID: 501B

#include <iostream>
#include <map> 

using namespace std;

int main() {
    map <string, string> handles;
    map<string, string> :: iterator it;
    
    string old_handle, new_handle;
    int n_changes;
    
    cin >> n_changes;
    
    while (n_changes--) {
        cin >> old_handle >> new_handle;
        
        if (handles.find(old_handle) != handles.end()) {
            handles[new_handle] = handles[old_handle];
            handles.erase(old_handle);
        } else {
            handles[new_handle] = old_handle;
        }
    }
    
    cout << handles.size() << endl;
    for(it = handles.begin(); it != handles.end(); it++) {
        cout << it->second << " " << it->first << endl;
    }
    
    return 0;
}
