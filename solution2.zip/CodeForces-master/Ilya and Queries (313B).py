# @author Matheus Alves dos Santos
# TITLE: Ilya and Queries
# ID: 313B

s = raw_input()
q = [0] * (len(s) + 1)

for i in range(1, len(s)):
    
    if(s[i] != s[i - 1]):
        q[i + 1] = q[i]
        
    else:
        q[i + 1] = q[i] + 1

m = int(raw_input())

for i in range(m):
    l, r = map(int, raw_input().split())    
    print q[r] - q[l]
