# @author Matheus Alves dos Santos
# TITLE: Watermelon
# ID: 4A

weight = int(raw_input())

if (weight <= 2) or ((weight % 2) != 0):
    print 'NO'
else:
    print 'YES'
