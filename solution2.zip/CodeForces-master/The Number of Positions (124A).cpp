// @author Matheus Alves dos Santos
// TITLE: The Number of Positions
// ID: 124A

#include <iostream>

using namespace std;

int main() {
    int n, a, b, positions = 0;
    cin >> n >> a >> b;
    
    for(int i = 1; i <= n; i++) {
        if ((i <= (n - a)) && (i <= b + 1)) {
            positions++;
        }
    }
    
    cout << positions;
    
    return 0;
}
