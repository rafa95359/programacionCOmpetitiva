// @author Matheus Alves dos Santos
// TITLE: Squares
// ID: 263B

#include <iostream>
#include <algorithm>

using namespace std;

int main(){

    int n_squares, inside;
    
    cin >> n_squares >> inside;
    int squares[n_squares];
    
    for(int i = 0; i < n_squares; i++) {
        cin >> squares[i];
    }
    
    sort(squares, squares + n_squares);
    
    if (inside <= n_squares) {
        cout << squares[n_squares - inside] << " 0";
    }
    else {
        cout << "-1"; 
    }
        
    return 0;
}
