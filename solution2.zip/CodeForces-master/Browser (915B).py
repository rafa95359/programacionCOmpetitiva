# @author Matheus Alves dos Santos
# TITLE: Browser
# ID: 915B

seconds = 0

n, p, l, r = map(int, raw_input().split())

if p < l:
    seconds += (l - p)
    p = l
if p > r:
    seconds += (p - r)
    p = r

left = (l > 1)    
right = (r < n)
    
if (left and right):
    seconds += + (min(p - l, r - p) + (r - l) + 2)
elif (left):
    seconds += (1 + (p - l))
elif (right):
    seconds += (1 + (r - p))

print seconds


