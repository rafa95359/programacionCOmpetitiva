# @author Matheus Alves dos Santos
# TITLE: Chess For Three
# ID: 893A

player1 = 1
player2 = 2
expect = 3

possible = True

n_tests = int(raw_input())
for i in range(n_tests):
    winner = int(raw_input())
    
    if winner == player1:
        player2, expect = expect, player2
    elif winner == player2:
        player1, expect = expect, player1
    else:
        possible = False

if possible:
    print 'YES'
else:
    print 'NO'
