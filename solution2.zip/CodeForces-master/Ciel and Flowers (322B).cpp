// @author Matheus Alves dos Santos
// TITLE: Ciel and Flowers
// ID: 322B

#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int flowers[3], bouquets = 0;
    bool okay = false;
    
    cin >> flowers[0] >> flowers[1] >> flowers[2];
    
    if ((flowers[0] > 0) && (flowers[1] > 0) && (flowers[2] > 0)) {
        okay = true;
    }
        
    bouquets += flowers[0] / 3;
    flowers[0] = flowers[0] % 3;
    
    bouquets += flowers[1] / 3;
    flowers[1] = flowers[1] % 3;
    
    bouquets += flowers[2] / 3;
    flowers[2] = flowers[2] % 3;
    
    sort(flowers, flowers + 3);
    
    bouquets += flowers[0];
    flowers[2] -= flowers[0];
    flowers[1] -= flowers[0];
    flowers[0] -= flowers[0];
    
    if ((flowers[0] == 0) && (flowers[1] == 2) && (flowers[2] == 2) && okay) {
        bouquets ++;
    }
    
    cout << bouquets;
    
    return 0;
}
