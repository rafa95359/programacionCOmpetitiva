// @author Matheus Alves dos Santos
// TITLE: Little Girl and Game
// ID: 276B

#include <iostream>

using namespace std;

int main(){
    
    int size, single = 0;
    std::string word;
    char alphabet[26];
    int appears[26];
    
    string az = "abcdefghijklmnopqrstuvwxyz";
    for(int i = 0; i < 26; i++) {
        alphabet[i] = az[i];
        appears[i] = 0;
    }
    
    cin >> word;
    size = word.size();
    
    for(int i = 0; i < size; i++) {
        for(int j = 0; j < 26; j++) {
            if (word[i] == alphabet[j]) {
                appears[j]++;
            }
        }
    }
    
    for(int i = 0; i < 26; i++) {
        if ((appears[i] % 2) == 0) {
            size -= appears[i];
        } else {
            size -= (appears[i] - 1);
            single++;
        }
    }
    
    if (((single + 1) % 2) == 0 || (single == 0)) {
        cout << "First";
    } else {
        cout << "Second";
    }
    
    return 0;
}
