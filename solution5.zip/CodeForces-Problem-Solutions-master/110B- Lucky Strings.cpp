#include<bits/stdc++.h>
using namespace std;
main(){
    int n;
    cin>>n;

    while(1){
        if(n==0) break;

        cout<<"a";

        n--;
        if(n==0) break;

        cout<<"b";

        n--;
        if(n==0) break;

        cout<<"c";

        n--;
        if(n==0) break;

        cout<<"d";

        n--;
    }

    puts("");



}
